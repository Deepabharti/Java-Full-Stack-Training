function show(msg)
{
console.log(msg);
}
function calculateArm(n)
{
return n*n*n;
}
function checkArmstrong(n)
{
let d=n
let sum=0;
while(d>0)
{
let digit=d%10;
d=parseInt(d/10);
sum+=calculateArm(digit);
}
if(sum==n) return 1;
else return 0;
}var mypromise=new Promise(function(resolve,reject){
let n=153;
let x=checkArmstrong(n);
if(x==1) resolve("Armstrong number");
else reject("Not an armstrong number");
});mypromise.then(function(value){show(value)},function(error){show(error)});

