//WAP to generate even no upto 10 and print the table of each no.
for(i=1;i<=10;i++)
{
if(i%2==0){
console.log(i);
for(let a = 1; a <= 10; a++) {

    // multiply i with number
    const result = i * a;

    // display the result
    console.log(i + "*" + a + "=" + result);
}
}
}
