 class Person{
  String Name ; 
  int Age; 
 
 // constructor
 public Person(String name, int age){
 this.Name = name;
 this.Age = age;
 
 }

 public String getName(){
 return Name;
 }

public int getAge(){
 return Age;
  }

 public void setName(String name){
 this.Name = name;
 }
 public void setAge(int age){
 this.Age = age;
 }

 public String toString(){
 return "Name: " + Name + ", age: " + Age ;
 }
}
 class collegeStudent extends student{
String collegename; 
 int year; 

// constructor
public collegeStudent( String name,int age,int studentid, String collegename, int year){

super(name,age,studentid);
this.collegename=collegename;
this.year = year;
}
public String collegename(){
return collegename;
}
public int year(){
return year;
 }
public void setcollegename(String collegename){
this.collegename=collegename;
}
public void setyear(int year){
this.year=year;
}

public String toString(){
return super.toString() + ", collegename: " + collegename + ", year: " + year;
}
}

class Teacher extends Person{
String subToTeach; 
 int salary; 

// constructor
public Teacher(String name, int age, String subToTeach, int salary){

super(name, age);
this.subToTeach=subToTeach;
this.salary = salary;
}
public String subToTeach(){
return subToTeach;
}
public int salary(){
return salary;
 }
public void setsubToTeach(String subToTeach){
this.subToTeach=subToTeach;
}
public void setsalary(int salary){
this.salary=salary;
}

public String toString(){
return super.toString() + ", subject to teach: " + subToTeach + ", salary: " + salary;
}
}


class student extends Person{

 int studentid; 

// constructor
public student(String name, int age, int studentid){

super(name,age);

this.studentid= studentid;
}
public int studentid(){
return studentid;
 }

public void setstudentid(int studentid){
this.studentid= studentid;
}

public String toString(){
return super.toString() + ", student id: " + studentid ;
}
}

public class inheritanceQ2{
public static void main(String[] args) {
Person per = new Person("Deepa bharti", 20);
System.out.println(per);
collegeStudent colstud = new collegeStudent("deepa bharti", 20,1015063, "iter", 2);
System.out.println(colstud);
Teacher tec = new Teacher("jaynam sir", 34,"Computer Science", 50000);
System.out.println(tec);
student stud = new student("riddhi", 18, 1015063);
System.out.println(stud);
}
}