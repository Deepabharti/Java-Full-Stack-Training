class Patient {
	String name;
	 double height;
	 double weight;
	
	public Patient(String name, double height, double weight) {
		super();
		this.name = name;
		this.height = height;
		this.weight = weight;
	}
	
	public double BMI () {

		return ( weight / ( height * height ) ) ;
	}
}

public class constructorQ2 {

	public static void main(String[] args) {
		Patient patient = new Patient("deepa bharti", 177/2.54, 59*2.2);
		
		System.out.println(patient.BMI());

	}

}