 class Box {
    double height;
	double width;
	double depth;

     Box(double width,double height,double depth)
    {
        System.out.println("Constructing Box");
		this.width = width;  
         this.height = height;  
		 this.depth = depth;
        
    }
    double volume()
    { 
	 return width * height * depth;
    }
	}
   public class perametarizeConstructorQ1{
    public static void main(String[] args) {
       
    Box b = new Box(10,10,10);
    System.out.println(b.volume());

    }

}